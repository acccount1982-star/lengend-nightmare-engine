# Lengend Nightmare Engine

An original, platform-neutral TypeScript engine for monster arena games. The package contains two composable simulation layers:

- a deterministic turn-based campaign engine for actions, resources, enemy behaviors, rewards, saves, and progression;
- a fixed-timestep real-time arena simulation with inputs, entities, movement, bounds, and collision hooks.

The engine has no React, DOM, Tailwind, browser storage, or native runtime dependency. Clients own rendering, input devices, and persistence adapters.

## Install

After the first GitHub release is published, install the versioned archive with one command:

```bash
pnpm add https://github.com/lengend-nightmare/engine/releases/download/v0.1.0/lengend-nightmare-engine-0.1.0.tgz
```

The URL is intentionally tied to a versioned release archive so applications can pin the engine and upgrade deliberately.

## Usage

```ts
import {
  createTurnBasedEngine,
  lengendNightmareCampaign,
} from "@workspace/lengend-nightmare-engine";

const engine = createTurnBasedEngine({
  campaign: lengendNightmareCampaign,
  seed: 1978,
});

const transition = engine.dispatch({
  type: "turn.action",
  actionId: "attack",
});

console.log(transition.snapshot, transition.events);
const save = engine.serialize();
```

When working inside this monorepo, use the workspace package instead:

```bash
pnpm --filter @workspace/lengend-nightmare-game add @workspace/lengend-nightmare-engine@workspace:*
```

For real-time play, create an arena with `createRealTimeArena`, send `arena.set-input` commands, and advance it with `arena.step`. The fixed timestep keeps simulation behavior reproducible across renderers.

## Distribution

`pnpm --filter @workspace/lengend-nightmare-engine run build` emits JavaScript and declaration files to `dist/`. The package is intentionally independent from the game clients so a future app, editor, or renderer can consume the same simulation contract.

Release preparation lives in `CHANGELOG.md`, with the current package version tracked in `package.json`. Run `pnpm --filter @workspace/lengend-nightmare-engine run pack:release` to build the package and write a versioned archive to `releases/`. The repository is ready for a GitHub remote and first release; no remote push is performed by this workspace.

## Originality

This is an original implementation inspired only by common arena-game structures. It does not include proprietary code, names, art, characters, or rules from other games.